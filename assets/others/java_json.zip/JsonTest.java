import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import net.sf.json.JsonConfig;
import net.sf.json.processors.JsonValueProcessor;

import com.alibaba.fastjson.serializer.SerializeConfig;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.SimpleDateFormatSerializer;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JsonTest {

	public void testFeatureSerialize() throws Exception {
		UserInfo userInfo = new UserInfo("maxchen", 22, 1, new Date(), "�㶫ʡ��������ɽ������԰ţ����Ϣ�������޹�˾");
		System.out.println("==========Ĭ������==========");
		System.out.println("gson:		"+new Gson().toJson(userInfo));
		System.out.println("json-lib:	"+net.sf.json.JSONObject.fromObject(userInfo));
		System.out.println("jackson:	"+new ObjectMapper().writeValueAsString(userInfo));
		System.out.println("fastjson:	"+com.alibaba.fastjson.JSON.toJSONString(userInfo));
		
		System.out.println("==========�߼�����==========");
		System.out.println("gson:		"+new GsonBuilder().serializeNulls().setDateFormat("yyyy-MM-dd HH:mm:ss").create().toJson(userInfo));
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.registerJsonValueProcessor(Date.class, new JsonValueProcessor() {
			   SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			   @Override
			   public Object processObjectValue(String propertyName, Object date,JsonConfig config) {
			      return simpleDateFormat.format(date);
			   }
			   @Override
			   public Object processArrayValue(Object date, JsonConfig config) {
			      return simpleDateFormat.format(date);
			   }
			});
		System.out.println("json-lib:	"+net.sf.json.JSONObject.fromObject(userInfo, jsonConfig).toString());
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		System.out.println("jackson:	"+objectMapper.writeValueAsString(userInfo));
		SerializeConfig config = new SerializeConfig();
		config.put(Date.class, new SimpleDateFormatSerializer("yyyy-MM-dd HH:mm:ss"));
		System.out.println("fastjson:	"+com.alibaba.fastjson.JSON.toJSONString(userInfo, config, SerializerFeature.WriteMapNullValue));
	}
	
	public void testFeatureUnserialize() throws Exception {
		String jsonStr = "{\"name\":\"maxchen\",\"age\":22,\"sex\":1,\"birth\":\"2016-05-18 15:19:57\",\"addr\":null,\"addr1\":null}";
		UserInfo userInfo1 = new Gson().fromJson(jsonStr, UserInfo.class);
		UserInfo userInfo2 = (UserInfo)net.sf.json.JSONObject.toBean(net.sf.json.JSONObject.fromObject(jsonStr), UserInfo.class);
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		UserInfo userInfo3 = objectMapper.readValue(jsonStr, UserInfo.class);
		UserInfo userInfo4 = com.alibaba.fastjson.JSON.parseObject(jsonStr, UserInfo.class);
	}
	
	
	public <T> void testSpeedSerialize(List<T> list) throws Exception {
		long time = System.currentTimeMillis();
		Gson gson = new Gson();
		for(T t:list)
			gson.toJson(t);
		System.out.println("gson:		"+(System.currentTimeMillis()-time));
		
		time = System.currentTimeMillis();
		for(T t:list)
			net.sf.json.JSONObject.fromObject(t).toString();
		System.out.println("json-lib:	"+(System.currentTimeMillis()-time));
		
		time = System.currentTimeMillis();
		ObjectMapper objectMapper = new ObjectMapper();
		for(T t:list)
			objectMapper.writeValueAsString(t);
		System.out.println("jackson:	"+(System.currentTimeMillis()-time));
		
		time = System.currentTimeMillis();
		for(T t:list)
			com.alibaba.fastjson.JSON.toJSONString(t);
		System.out.println("fastjson:	"+(System.currentTimeMillis()-time));
	}
	
	public void testSpeedUnserialize(List<String> list, Class<?> clazz) throws Exception {
		long time = System.currentTimeMillis();
		for(String str:list)
			new Gson().fromJson(str, clazz);
		System.out.println("gson:		"+(System.currentTimeMillis()-time));
		
		time = System.currentTimeMillis();
		for(String str:list)
			net.sf.json.JSONObject.toBean(net.sf.json.JSONObject.fromObject(str), clazz);
		System.out.println("json-lib:	"+(System.currentTimeMillis()-time));
		
		time = System.currentTimeMillis();
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		for(String str:list)
			objectMapper.readValue(str, clazz);
		System.out.println("jackson:	"+(System.currentTimeMillis()-time));
		
		time = System.currentTimeMillis();
		for(String str:list)
			com.alibaba.fastjson.JSON.parseObject(str, clazz);
		System.out.println("fastjson:	"+(System.currentTimeMillis()-time));
	}
	
	public static void main(String[] args) throws Exception
	{
		JsonTest jsonTest = new JsonTest();
		/**���ܲ���*/
//		jsonTest.testFeatureSerialize();
//		jsonTest.testFeatureUnserialize();
		
		/**���ܲ���*/
//		List<Object> list = new ArrayList<Object>();
		List<String> list = new ArrayList<String>();
		for(int i=0;i<100000;i++)
		{
			Random r = new Random();
//			Object obj = new UserInfo("maxchen", r.nextInt(100), r.nextInt(2), new Date(), "�㶫ʡ��������ɽ������԰ţ����Ϣ�������޹�˾");
			Ware obj = new Ware();
			obj.setWareId(r.nextLong());
			obj.setSpuId(r.nextLong());
			obj.setCategoryId(r.nextLong());
			obj.setVenderId(r.nextLong());
			obj.setShopId(r.nextLong());
			obj.setWareStatus(String.valueOf(r.nextInt(100)));
			obj.setTitle(String.valueOf(r.nextLong()));
			List<Sku> skus = new ArrayList<Sku>();
			for(int j=0;j<3;j++)
			{
				Sku sku = new Sku();
				sku.setSkuId(r.nextLong());
				sku.setWareId(r.nextLong());
				sku.setShopId(r.nextLong());
				sku.setStatus(String.valueOf(r.nextInt(10)));
				sku.setAttributes(String.valueOf(r.nextInt(10)));
				sku.setJdPrice(String.valueOf(r.nextInt(10000)));
				sku.setCostPrice(String.valueOf(r.nextInt(10000)));
				sku.setMarketPrice(String.valueOf(r.nextInt(10000)));
				sku.setStockNum(r.nextInt(1000));
				sku.setOuterId(String.valueOf(r.nextLong()));
				sku.setCreated(String.valueOf(r.nextLong()));
				sku.setModified(String.valueOf(r.nextLong()));
				sku.setColorValue(String.valueOf(r.nextInt(100)));
				sku.setSizeValue(String.valueOf(r.nextInt(100)));
				skus.add(sku);
			}
			obj.setSkus(skus);

			String str = new GsonBuilder().serializeNulls().setDateFormat("yyyy-MM-dd HH:mm:ss").create().toJson(obj);
			list.add(str);
		}
//		jsonTest.testSpeedSerialize(list);
		jsonTest.testSpeedUnserialize(list, Ware.class);
	}
}