
public class Sku
{
  private Long skuId;
  private long wareId;
  private long shopId;
  private String status;
  private String attributes;
  private String jdPrice;
  private String costPrice;
  private String marketPrice;
  private long stockNum;
  private String outerId;
  private String created;
  private String modified;
  private String colorValue;
  private String sizeValue;
public Long getSkuId() {
	return skuId;
}
public void setSkuId(Long skuId) {
	this.skuId = skuId;
}
public long getWareId() {
	return wareId;
}
public void setWareId(long wareId) {
	this.wareId = wareId;
}
public long getShopId() {
	return shopId;
}
public void setShopId(long shopId) {
	this.shopId = shopId;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getAttributes() {
	return attributes;
}
public void setAttributes(String attributes) {
	this.attributes = attributes;
}
public String getJdPrice() {
	return jdPrice;
}
public void setJdPrice(String jdPrice) {
	this.jdPrice = jdPrice;
}
public String getCostPrice() {
	return costPrice;
}
public void setCostPrice(String costPrice) {
	this.costPrice = costPrice;
}
public String getMarketPrice() {
	return marketPrice;
}
public void setMarketPrice(String marketPrice) {
	this.marketPrice = marketPrice;
}
public long getStockNum() {
	return stockNum;
}
public void setStockNum(long stockNum) {
	this.stockNum = stockNum;
}
public String getOuterId() {
	return outerId;
}
public void setOuterId(String outerId) {
	this.outerId = outerId;
}
public String getCreated() {
	return created;
}
public void setCreated(String created) {
	this.created = created;
}
public String getModified() {
	return modified;
}
public void setModified(String modified) {
	this.modified = modified;
}
public String getColorValue() {
	return colorValue;
}
public void setColorValue(String colorValue) {
	this.colorValue = colorValue;
}
public String getSizeValue() {
	return sizeValue;
}
public void setSizeValue(String sizeValue) {
	this.sizeValue = sizeValue;
}
  
}
